import dotenv from "dotenv";
import { logger } from "../utils/logger.js";

export function loadEnv() {
  dotenv.config();
  const required = ["MONGODB_URI", "MONGODB_DB", "API_KEY", "OPENAI_API_KEY"];
  const missing = required.filter((k) => !process.env[k] || String(process.env[k]).trim() === "");
  if (missing.length) console.warn(`[env] Faltan variables: ${missing.join(", ")} (revisa .env)`);

  // Log seguro para verificar que OPENAI_API_KEY se cargó (sin exponerla completa)
  const k = process.env.OPENAI_API_KEY || "";
  if (k) {
    const masked = `${k.slice(0, 6)}...${k.slice(-4)}`;
    logger.info({ msg: "OPENAI_API_KEY loaded", masked, length: k.length });
  } else {
    logger.warn({ msg: "OPENAI_API_KEY not set at startup" });
  }
}
