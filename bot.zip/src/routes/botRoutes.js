import { Router } from "express";
import { requireApiKey } from "../middlewares/auth.js";
import { handleBotMessage } from "../controllers/botController.js";

export const botRouter = Router();
botRouter.post("/message", requireApiKey, handleBotMessage);
